static int sum(int val1, val2) {
    val1 + val2
}